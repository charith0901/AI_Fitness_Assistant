import { useLocation, useNavigate } from 'react-router-dom';

function Result() {
  const location = useLocation();
  const navigate = useNavigate();
  const prediction = location.state?.prediction;

  if (!prediction) {
    navigate('/');
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="bg-indigo-50 p-6 rounded-lg border border-indigo-100">
        <h2 className="text-xl font-semibold text-gray-800 mb-2">Your Recommended Plan</h2>
        <div className="p-4 bg-white rounded-md shadow-sm">
          <p className="text-lg font-medium text-indigo-700">{prediction}</p>
        </div>
      </div>
      
      <div className="text-center mt-6">
        <button 
          onClick={() => navigate('/')} 
          className="px-6 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-gray-300"
        >
          ← Back to Form
        </button>
      </div>
    </div>
  );
}

export default Result;
