import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Home() {
  const [formData, setFormData] = useState({
    Age: '',
    Gender: '',
    Weight: '',
    Goal: '',
    ActivityLevel: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const response = await axios.post('http://localhost:8000/predict', {
        Age: parseInt(formData.Age),
        Gender: parseInt(formData.Gender),
        Weight: parseFloat(formData.Weight),
        Goal: parseInt(formData.Goal),
        ActivityLevel: parseInt(formData.ActivityLevel),
      });
      navigate('/result', { state: { prediction: response.data.predicted_plan } });
    } catch (error) {
      console.error('Error making prediction:', error);
      alert('Error making prediction. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const inputClass = "w-full px-4 py-2 mt-1 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent";
  const labelClass = "block text-sm font-medium text-gray-700 mb-1";
  const formGroupClass = "mb-6";

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="formGroupClass">
        <label className={labelClass}>
          Age
        </label>
        <input 
          type="number" 
          name="Age" 
          value={formData.Age} 
          onChange={handleChange} 
          required 
          className={inputClass}
          placeholder="Enter your age"
        />
      </div>
      
      <div className={formGroupClass}>
        <label className={labelClass}>
          Gender
        </label>
        <select 
          name="Gender" 
          value={formData.Gender} 
          onChange={handleChange} 
          required 
          className={inputClass}
        >
          <option value="">Select gender</option>
          <option value="0">Female</option>
          <option value="1">Male</option>
        </select>
      </div>
      
      <div className={formGroupClass}>
        <label className={labelClass}>
          Weight (kg)
        </label>
        <input 
          type="number" 
          name="Weight" 
          value={formData.Weight} 
          onChange={handleChange} 
          required 
          className={inputClass}
          placeholder="Enter your weight in kg"
          step="0.1"
        />
      </div>
      
      <div className={formGroupClass}>
        <label className={labelClass}>
          Goal
        </label>
        <select 
          name="Goal" 
          value={formData.Goal} 
          onChange={handleChange} 
          required 
          className={inputClass}
        >
          <option value="">Select your goal</option>
          <option value="0">Lose Weight</option>
          <option value="1">Maintain Weight</option>
          <option value="2">Gain Muscle</option>
        </select>
      </div>
      
      <div className={formGroupClass}>
        <label className={labelClass}>
          Activity Level
        </label>
        <select 
          name="ActivityLevel" 
          value={formData.ActivityLevel} 
          onChange={handleChange} 
          required 
          className={inputClass}
        >
          <option value="">Select activity level</option>
          <option value="0">Sedentary</option>
          <option value="1">Lightly Active</option>
          <option value="2">Moderately Active</option>
          <option value="3">Very Active</option>
        </select>
      </div>
      
      <div className="mt-8">
        <button 
          type="submit" 
          className="w-full px-4 py-2 text-white font-medium bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors disabled:bg-indigo-400 disabled:cursor-not-allowed"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Predicting...' : 'Predict Fitness Plan'}
        </button>
      </div>
    </form>
  );
}

export default Home;
